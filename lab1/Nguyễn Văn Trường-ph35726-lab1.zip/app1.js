//Nhập dữ liệu
var x = prompt("Input n: ");
//Xuất dữ liệu ra màn hình
  document.write(x);